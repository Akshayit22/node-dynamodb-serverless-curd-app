# node-dynamodb-serverless-curd-app
